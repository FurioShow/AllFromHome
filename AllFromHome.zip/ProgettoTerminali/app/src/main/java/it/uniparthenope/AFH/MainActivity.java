package it.uniparthenope.AFH;

import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private EditText email, pass;
    private Button register;
    private CardView login;
    RadioButton cliente, venditore;
    private FirebaseAuth mAuth;
    DatabaseReference db;
    DataSnapshot ds;
    Intent i;
    private ProgressBar bar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        bar = findViewById(R.id.progressBar2);
        bar.setVisibility(View.INVISIBLE);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance().getReference().child("Users");


        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ds = dataSnapshot;
                Log.e("tuple presenti ", "" + dataSnapshot.getChildrenCount());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        email = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);
        cliente = findViewById(R.id.cliente);
        venditore = findViewById(R.id.venditore);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Register.class);
                startActivity(i);
            }
        });

        try {
            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (checkLogin()) {
                        bar.setVisibility(View.VISIBLE);

                        mAuth.signInWithEmailAndPassword(email.getText().toString(), pass.getText().toString())
                                .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            bar.setVisibility(View.VISIBLE);
                                            //Verifica email sia verificata

                                            if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()) {
                                                //Verifico che il tipo di cliente corrisponda
                                                db.child(mAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        User user = dataSnapshot.getValue(User.class);
                                                        boolean check = true;
                                                        if (user == null) {
                                                            bar.setVisibility(View.INVISIBLE);
                                                            Log.e("A", "A");
                                                            Toast.makeText(MainActivity.this, "Authentication failed.\nRiprova",
                                                                    Toast.LENGTH_SHORT).show();
                                                            return;
                                                        } else {
                                                            if (user.getTipo().compareTo("Venditore") == 0 && venditore.isChecked()) {
                                                                i = new Intent(MainActivity.this, VendorLogin.class);
                                                                i.putExtra("nome", user.getNomeAttivita());
                                                            } else if (user.getTipo().compareTo("Cliente") == 0 && cliente.isChecked()) {
                                                                i = new Intent(MainActivity.this, ClientLogin.class);
                                                            } else {
                                                                check = false;
                                                                Log.e("B", "B");
                                                                bar.setVisibility(View.INVISIBLE);
                                                                Toast.makeText(MainActivity.this, "Autenticazione fallita.\nRiprova",
                                                                        Toast.LENGTH_SHORT).show();
                                                            }

                                                            //Se tutto OK
                                                            if (check) {
                                                                resetToken();
                                                                startActivity(i);
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                                        Log.e("C", "C");
                                                        bar.setVisibility(View.INVISIBLE);
                                                        Toast.makeText(MainActivity.this, "Autenticazione fallita.\nRiprova",
                                                                Toast.LENGTH_SHORT).show();
                                                    }
                                                });
                                            } else {
                                                bar.setVisibility(View.INVISIBLE);
                                                Toast.makeText(MainActivity.this, "Please verify your email", Toast.LENGTH_SHORT).show();
                                            }

                                        } else {
                                            Log.e("D", "D");
                                            bar.setVisibility(View.INVISIBLE);
                                            Toast.makeText(MainActivity.this, "Autenticazione fallita.\n" + task.getException().getMessage(),
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkLogin() {
        if (email.getText().toString().isEmpty() || pass.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity.this, "Riempi il form", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!(venditore.isChecked() || cliente.isChecked())) {
            Toast.makeText(MainActivity.this, "Seleziona il tipo di utente", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void resetToken() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    FirebaseInstanceId.getInstance().deleteInstanceId();
                    FirebaseInstanceId.getInstance().getInstanceId()
                            .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                @Override
                                public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                    if (!task.isSuccessful()) {
                                        Log.w("getInstanceId failed", task.getException());
                                        return;
                                    }

                                    // Get new Instance ID token
                                    String token = task.getResult().getToken();
                                    FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("token").setValue(token);
                                }
                            });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
