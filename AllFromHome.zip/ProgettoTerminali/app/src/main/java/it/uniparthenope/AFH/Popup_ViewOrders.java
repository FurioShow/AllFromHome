package it.uniparthenope.AFH;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import android.widget.RatingBar;

import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;



public class Popup_ViewOrders extends AppCompatDialogFragment {
    private Order order;
    private Context c;
    private String idorder;
    private RatingBar ratingBar;

    public Popup_ViewOrders(Order order, Context context, String id) {
        this.order = order;
        this.c = context;
        this.idorder = id;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        try {
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.layout_view_orders, null);
            ratingBar = view.findViewById(R.id.ratingBar);

            final TextView data, destinazione, stato, prezzo, uid, email, textemail, nomecognome;
            TableLayout table;
            TableRow row;

            uid = view.findViewById(R.id.uid);
            uid.setText("ID ordine: " + idorder);
            data = view.findViewById(R.id.data);
            destinazione = view.findViewById(R.id.destinazione);
            stato = view.findViewById(R.id.stato);
            prezzo = view.findViewById(R.id.prezzo);
            table = view.findViewById(R.id.table);
            nomecognome = view.findViewById(R.id.textView17);
            email = view.findViewById(R.id.email);
            textemail = view.findViewById(R.id.textemail);

            DatabaseReference getclientemail = FirebaseDatabase.getInstance().getReference().child("Users").child(order.getUidbuyer());
            getclientemail.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    email.setText(dataSnapshot.getValue(User.class).getEmail());
                    nomecognome.setText(dataSnapshot.getValue(User.class).getNome() + " " +
                            dataSnapshot.getValue(User.class).getCognome());

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            if (order.getUidvendor().compareTo(FirebaseAuth.getInstance().getUid()) == 0) {


                email.setVisibility(View.VISIBLE);
                textemail.setVisibility(View.VISIBLE);
            }


            data.setText(order.getData());
            destinazione.setText(order.getDestination());
            stato.setText(order.getState());

            if ((stato.getText().toString().toLowerCase().compareTo("consegnato") != 0) ||
                    order.getUidvendor().compareTo(FirebaseAuth.getInstance().getUid()) == 0) {
                ratingBar.setVisibility(View.INVISIBLE);

            }

            //CREAZIONE TABELLA PRODOTTI ORDINE
            double costotot = 0;
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
            float density = c.getResources().getDisplayMetrics().density; //Fattore per passare da dp a pixel
            lp.setMargins((int) (20 * density), 0, 0, 0);


            for (int i = 0; i < order.getProduct().size(); i++) {
                Product prod = order.getProduct().get(i);
                costotot += prod.getPrezzo();
                row = new TableRow(c);
                TextView cat, desc, quant, prez;
                cat = new TextView(c);
                desc = new TextView(c);
                quant = new TextView(c);
                prez = new TextView(c);

                cat.setText(prod.getCateg());
                cat.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                desc.setText(prod.getDesc());
                desc.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                quant.setText(String.valueOf(prod.getQuantita()) + prod.getUnita());
                quant.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                prez.setText(String.valueOf(prod.getPrezzo()) + "€");
                prez.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                row.addView(cat);
                row.addView(desc, lp);
                row.addView(quant, lp);
                row.addView(prez, lp);

                table.addView(row, new TableLayout.LayoutParams(
                        TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));


            }

            prezzo.setText(String.valueOf(costotot) + "€");

            ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(final RatingBar ratingBar, float v, boolean b) {
                    final DatabaseReference db = FirebaseDatabase.getInstance().getReference().child("Feedbacks");

                    db.addListenerForSingleValueEvent(new ValueEventListener() {

                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            try {

                                int i = 0;
                                DatabaseReference changefeed = FirebaseDatabase.getInstance().getReference().child("Feedbacks");
                                for (DataSnapshot list : dataSnapshot.getChildren()) {
                                    if (list.getKey().compareTo(idorder) == 0)
                                        i++;
                                }
                                if (i == 0) {
                                    Feedback feed = new Feedback(order.getUidvendor(), order.getUidbuyer(),
                                            (int) ratingBar.getRating());

                                    changefeed.child(idorder).setValue(feed);
                                    changefeed.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            //AGGIORNAMENTO MEDIA FEEDBACK DEL VENDITORE
                                            int media = 0;
                                            int numfeed = 0;
                                            for (DataSnapshot list : dataSnapshot.getChildren()) {
                                                if (list.getValue(Feedback.class).getUidvendor().compareTo(order.getUidvendor()) == 0) {

                                                    media = media + list.getValue(Feedback.class).getFeed();
                                                    numfeed++;
                                                }


                                            }
                                            DatabaseReference changemedia = FirebaseDatabase.getInstance().getReference().child("Users").child(order.getUidvendor());
                                            Log.e("numfeed", String.valueOf(numfeed));
                                            if (numfeed > 0)
                                                media = media / numfeed;
                                            changemedia.child("media").setValue(media);
                                            Toast.makeText(c, "Thank you for rating!", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });


                                } else
                                    Toast.makeText(c, "Hai gia votato!", Toast.LENGTH_SHORT).show();

                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                                Toast.makeText(c, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            });

            builder.setView(view)
                    .setTitle("Visualizza ordine")
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            return builder.create();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(c, "Si è verificato un errore: " + e.getMessage(),Toast.LENGTH_SHORT).show();
            return null;
        }
    }


}
