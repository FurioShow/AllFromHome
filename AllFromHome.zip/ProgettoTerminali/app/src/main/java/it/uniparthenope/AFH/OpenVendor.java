package it.uniparthenope.AFH;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;

import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OpenVendor extends AppCompatActivity implements Popup_SelectDest.PopupSelDestListener {

    private Button buy;
    private String uid;
    private TableLayout table;
    private TableRow row;
    private DatabaseReference db;
    private TextView categ, desc, prezzo, quantita, nome;
    private EditText scelta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_vendor);
        uid = getIntent().getStringExtra("uid");
        table = findViewById(R.id.table);
        nome = findViewById(R.id.nomeAttivita);
        nome.setText(getIntent().getStringExtra("negozio"));
        buy = findViewById(R.id.button3);


        riempiTable();


        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                opendialog();
            }
        });

    }


    public void riempiTable() {
        db = FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Products");
        db.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                    TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
                    float density = getApplicationContext().getResources().getDisplayMetrics().density; //Fattore per passare da dp a pixel
                    lp.setMargins((int) (20 * density), 0, 0, 0);

                    TableRow first = (TableRow) table.getChildAt(0);
                    table.removeAllViews();
                    table.addView(first, lp);

                    for (DataSnapshot list : dataSnapshot.getChildren()) {
                        row = new TableRow(OpenVendor.this);
                        scelta = new EditText(OpenVendor.this);
                        scelta.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        scelta.getBackground().setColorFilter(getResources().getColor(R.color.black),
                                PorterDuff.Mode.SRC_ATOP);


                        row.setClickable(true);
                        desc = new TextView(OpenVendor.this);
                        prezzo = new TextView(OpenVendor.this);
                        quantita = new TextView(OpenVendor.this);
                        categ = new TextView(OpenVendor.this);
                        Product prod = list.getValue(Product.class);
                        categ.setText(prod.getCateg());
                        categ.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                        desc.setText(prod.getDesc());
                        desc.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                        quantita.setText(Double.toString(prod.getQuantita()) + " " + prod.getUnita());
                        quantita.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                        prezzo.setText(Double.toString(prod.getPrezzo()) + " al " + prod.getUnita());
                        prezzo.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                        row.addView(categ);
                        row.addView(desc, lp);
                        row.addView(quantita, lp);
                        row.addView(prezzo, lp);
                        row.addView(scelta, lp);
                        table.addView(row, lp);
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public void opendialog() {
        Popup_SelectDest tempp = new Popup_SelectDest();
        tempp.show(getSupportFragmentManager(), "Destinazione");
    }


    @Override
    public void applytexts(final String indirizzo) {

        Geocoder geo = new Geocoder(getApplicationContext());
        List<Address> addresses;


        try {
            addresses = geo.getFromLocationName(indirizzo, 1);
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), "Address not found: retry", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return;
        }

//SE LA DESTINAZIONE SCELTA E' VALIDA
        if (addresses.size() > 0)
            try {
                Log.e("indirizzi", indirizzo + String.valueOf(addresses.size()));
                db.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        ArrayList<Product> products = new ArrayList<>();
                        ArrayList<String> productskey = new ArrayList<>();
                        for (DataSnapshot list : dataSnapshot.getChildren()) {
                            products.add(list.getValue(Product.class));
                            productskey.add(list.getKey());
                        }

                        ArrayList<String> changekey = new ArrayList<>();
                        ArrayList<Product> prodscelti = new ArrayList<>();
                        Double[] nuovaquant = new Double[table.getChildCount()];
                        int k = 0;
                        for (int i = 1; i < table.getChildCount(); i++) {

                            TableRow rowtemp = (TableRow) table.getChildAt(i);
                            EditText quantscelta = (EditText) rowtemp.getChildAt(4);
                            if (quantscelta.getText().toString().compareTo("") != 0 && Double.parseDouble(quantscelta.getText().toString()) > 0 &&
                                    Double.parseDouble(quantscelta.getText().toString()) <= products.get(i - 1).getQuantita()) {
                                changekey.add(productskey.get(i - 1));
                                double pagamento = 0;
                                //CALCOLA PAGAMENTI SINGOLI PRODOTTI
                                if (products.get(i - 1).getUnita().toLowerCase().compareTo("pzz") == 0)
                                    pagamento = products.get(i - 1).getPrezzo() * (int) Double.parseDouble(quantscelta.getText().toString());
                                else
                                    pagamento = products.get(i - 1).getPrezzo() * Double.parseDouble(quantscelta.getText().toString());


                                //INSERISCE PRODOTTI NELL ORDINE
                                if (products.get(i - 1).getUnita().toLowerCase().compareTo("pzz") == 0)
                                    prodscelti.add(new Product(products.get(i - 1).getCateg(), products.get(i - 1).getDesc(),
                                            pagamento, (int) Double.parseDouble(quantscelta.getText().toString()), products.get(i - 1).getUnita()));
                                else
                                    prodscelti.add(new Product(products.get(i - 1).getCateg(), products.get(i - 1).getDesc(),
                                            pagamento, Double.parseDouble(quantscelta.getText().toString()), products.get(i - 1).getUnita()));

                                //AGGIORNA QUANTITA PRODOTTI
                                if (products.get(i - 1).getUnita().toLowerCase().compareTo("pzz") == 0)
                                    nuovaquant[k] = products.get(i - 1).getQuantita() - (int) Double.parseDouble(quantscelta.getText().toString());


                                else
                                    nuovaquant[k] = products.get(i - 1).getQuantita() - Double.parseDouble(quantscelta.getText().toString());


                                k++;

                            }
                        }
                        if (prodscelti.size() > 0) {
                            Order order = new Order(prodscelti, indirizzo.toLowerCase(), uid, FirebaseAuth.getInstance().getUid());
                            DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Orders");
                            data.push().setValue(order);
                            //MODIFICA QUANTITA PRODOTTI ACQUISTATI
                            for (int i = 0; i < prodscelti.size(); i++) {
                                data = FirebaseDatabase.getInstance().getReference().child("Users").child(uid).
                                        child("Products").child(changekey.get(i));


                                data.child("quantita").setValue(nuovaquant[i]);
                            }
                            Toast.makeText(getApplicationContext(), "Order complete!", Toast.LENGTH_SHORT).show();
                        } else
                            Toast.makeText(getApplicationContext(), "Error: non hai comprato niente", Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            } catch (Exception e) {
                e.printStackTrace();
            }
        else
            Toast.makeText(getApplicationContext(), "Address not found: retry", Toast.LENGTH_SHORT).show();


    }
}
