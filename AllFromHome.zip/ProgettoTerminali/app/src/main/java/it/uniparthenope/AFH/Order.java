package it.uniparthenope.AFH;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Order {
    ArrayList<Product> product;
    String destination;
    String data;
    String uidvendor;
    String uidbuyer;
    String state;

    public Order(ArrayList<Product> product, String dest, String uidv, String uidb) {
        this.product = product;
        this.destination = dest;
        this.uidvendor = uidv;
        this.uidbuyer = uidb;
        this.state = "In attesa di conferma";

        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy hh:mm");

        this.data = s.format(new Date());
    }

    public Order() {
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUidvendor() {
        return uidvendor;
    }

    public void setUidvendor(String uidvendor) {
        this.uidvendor = uidvendor;
    }

    public String getUidbuyer() {
        return uidbuyer;
    }

    public void setUidbuyer(String uidbuyer) {
        this.uidbuyer = uidbuyer;
    }

    public ArrayList<Product> getProduct() {
        return product;
    }

    public void setProduct(ArrayList<Product> product) {
        this.product = product;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String dest) {
        this.destination = dest;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
