package it.uniparthenope.AFH;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;

import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class VendorLogin extends AppCompatActivity {

    private DrawerLayout drawer;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Profilo");
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();

        retrieveinfo();
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(isNetworkAvailable())
                try {
                    if (id == R.id.nav_orders) {
                        Intent i = new Intent(VendorLogin.this, VendorOrders_nav.class);
                        startActivity(i);
                    } else if (id == R.id.nav_products) {
                        Intent i = new Intent(VendorLogin.this, VendorProducts_nav.class);
                        i.putExtra("nome",getIntent().getStringExtra("nome"));
                        startActivity(i);
                    } else if (id == R.id.contactus) {
                        Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                    } else if (id == R.id.logout) {
                        mAuth.signOut();
                        Intent i = new Intent(VendorLogin.this, MainActivity.class);
                        startActivity(i);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                else
                    Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                return false;
            }
        });
    }


    private void retrieveinfo() {
        try {
            final TextView nomeatt, indirizzo, phone, email;
            nomeatt = findViewById(R.id.name);
            indirizzo = findViewById(R.id.address);
            phone = findViewById(R.id.mobileNumber);
            email = findViewById(R.id.email);

            DatabaseReference db = FirebaseDatabase.getInstance().getReference().child("Users").child(mAuth.getUid());
            db.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User u = dataSnapshot.getValue(User.class);

                    nomeatt.setText(u.getNomeAttivita());
                    indirizzo.setText(u.getIndirizzo());
                    phone.setText(u.getNumber());
                    email.setText(u.getEmail());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            System.exit(0);
        }
    }
}
