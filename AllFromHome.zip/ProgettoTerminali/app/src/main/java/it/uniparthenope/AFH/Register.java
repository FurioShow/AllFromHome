package it.uniparthenope.AFH;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Register extends AppCompatActivity {
    private EditText email, pass, comune, via, nomeAttivita, phone, cognome;
    private Spinner cat;
    private Button register;
    private RadioGroup group;
    private RadioButton selected;
    private AlertDialog.Builder builder;
    private FirebaseAuth mAuth;
    private ProgressBar bar;
    private DatabaseReference db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        cognome = findViewById(R.id.cognome);
        bar = findViewById(R.id.progressBar);
        group = findViewById(R.id.radiogroup);
        email = findViewById(R.id.email1);
        pass = findViewById(R.id.pass1);
        comune = findViewById(R.id.comune);
        via = findViewById(R.id.via);

        nomeAttivita = findViewById(R.id.nomeAttivita);
        builder = new AlertDialog.Builder(this);
        register = findViewById(R.id.register1);
        cat = findViewById(R.id.categoria);
        phone = findViewById(R.id.phone);
        mAuth = FirebaseAuth.getInstance();
        ArrayList<String> list = new ArrayList<>(Arrays.asList("Panificio", "Fruttivendolo", "Pasticceria", "Salumeria"));
        ArrayAdapter<String> adap = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, list);
        cat.setAdapter(adap);
        selected = findViewById(R.id.cliente1);


        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                selected = findViewById(checkedId);
                if (selected.getText().toString().compareTo("Cliente") == 0) {
                    nomeAttivita.setHint("Nome");
                    cognome.setVisibility(View.VISIBLE);
                    cat.setVisibility(View.INVISIBLE);
                } else if (selected.getText().toString().compareTo("Venditore") == 0) {
                    nomeAttivita.setHint("Nome attività");
                    cognome.setVisibility(View.INVISIBLE);
                    cat.setVisibility(View.VISIBLE);
                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkInsert()) {
                    bar.setVisibility(View.VISIBLE);
                    createAccount(email.getText().toString(), pass.getText().toString());
                }
            }
        });
    }

    public void createAccount(final String email, final String password) {
        try {
            if (validaddress(via.getText().toString() + " " + comune.getText().toString()))
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    //Verifica Email
                                    FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                User u = null;
                                                Toast.makeText(Register.this, "Registration Successfull!\nPlease check your email address to verify", Toast.LENGTH_LONG).show();
                                                if (selected.getText().toString().compareTo("Venditore") == 0)
                                                    u = new User(via.getText().toString() + " " + comune.getText().toString(),
                                                            nomeAttivita.getText().toString(), cat.getSelectedItem().toString(), selected.getText().toString(), email, phone.getText().toString());
                                                else if (selected.getText().toString().compareTo("Cliente") == 0)
                                                    u = new User(via.getText().toString() + " " + comune.getText().toString(), null,
                                                            selected.getText().toString(), email, nomeAttivita.getText().toString(), cognome.getText().toString(), phone.getText().toString());

                                                db = FirebaseDatabase.getInstance().getReference("Users");
                                                db.child(mAuth.getUid()).setValue(u);
                                                mAuth.signOut();
                                                startActivity(new Intent(getApplicationContext(), MainActivity.class));

                                            } else {
                                                Toast.makeText(Register.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                bar.setVisibility(View.INVISIBLE);
                                            }

                                        }
                                    });
                                } else {
                                    Toast.makeText(Register.this, "Error!\n" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    bar.setVisibility(View.INVISIBLE);
                                }
                            }
                        });
            else {
                Toast.makeText(Register.this, "Address not found", Toast.LENGTH_SHORT).show();
                bar.setVisibility(View.INVISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }


    private boolean validaddress(String address) {
        try {

            Geocoder geo = new Geocoder(getApplicationContext());
            List<Address> l = geo.getFromLocationName(address, 1);
            return l.size() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }

    private boolean checkInsert() {
        if (pass.getText().toString().trim().length() < 6) {
            Toast.makeText(getApplicationContext(), "La password deve essere almeno 6 caratteri", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (selected == null) {
            Toast.makeText(Register.this, "Seleziona il tipo di utente", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (selected.getText().toString().compareTo("Cliente") == 0)
            if (isEmpty(email) || isEmpty(pass) || isEmpty(comune) || isEmpty(via)) {
                Toast.makeText(getApplicationContext(), "Compilare tutti i campi", Toast.LENGTH_SHORT).show();
                return false;
            }
        if (selected.getText().toString().compareTo("Venditore") == 0)
            if (isEmpty(email) || isEmpty(pass) || isEmpty(comune) || isEmpty(via) || isEmpty(nomeAttivita)) {
                Toast.makeText(getApplicationContext(), "Compilare tutti i campi", Toast.LENGTH_SHORT).show();
                return false;
            }
        return true;
    }

}
