package it.uniparthenope.AFH;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class Gpstracker implements LocationListener {
    private Context context;
    private Location l;

    Gpstracker(Context C) {
        context = C;

    }

    public Location getlocation() {

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "Permission not granted", Toast.LENGTH_SHORT).show();
            return null;
        }
        try {
            LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            Boolean gpsen = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsen) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 6000, 10, this);
                l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l == null)
                    l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                return l;
            } else {
                Toast.makeText(context, "gps not enabled", Toast.LENGTH_SHORT).show();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onLocationChanged(Location location) {
        l = location;
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


}
