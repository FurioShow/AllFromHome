package it.uniparthenope.AFH;

import android.content.Context;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;


import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Init_mappa {

    private ArrayList<ArrayList<String>> res;

    public void initialize(final Context C, final String raggio, final GoogleMap mMap) {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference().child("Users");


        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                res = new ArrayList<>();

                try {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        ArrayList<String> temp = new ArrayList<>();
                        if (postSnapshot.getValue(User.class).getTipo().compareTo("Venditore") == 0) {
                            temp.add(postSnapshot.getValue(User.class).getIndirizzo());
                            temp.add(postSnapshot.getValue(User.class).getNomeAttivita());
                            temp.add(postSnapshot.getValue(User.class).getCategoria());
                            temp.add(postSnapshot.getKey());
                            temp.add(String.valueOf(postSnapshot.getValue(User.class).getMedia()));
                            temp.add(postSnapshot.getValue(User.class).getEmail());
                            res.add(temp);

                        }
                    }

                    initialized(C, raggio, mMap);

                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(C, "Database error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(C, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void initialized(final Context C, String raggio, GoogleMap mMap) {

        mMap.clear();
        Geocoder geo = new Geocoder(C);
        List<Address> l;

        Location mypos = new Gpstracker(C).getlocation();
        ArrayList<Address> coordinatenegozi = new ArrayList<>();
        ArrayList<String> nominegozi = new ArrayList<>();
        ArrayList<LatLng> valide = new ArrayList<>();
        ArrayList<String> categorie = new ArrayList<>();
        ArrayList<String> uid = new ArrayList<>();
        ArrayList<String> feeds = new ArrayList<>();
        ArrayList<String> emails = new ArrayList<>();

        try {


            if (res != null) //convertire le vie dei negozi in coordinate
            {
                for (int i = 0; i < res.size(); i++) {

                    l = geo.getFromLocationName(res.get(i).get(0), 1);
                    if (l.size() > 0)
                        coordinatenegozi.add(l.get(0));

                }
            }

            //ESTRAZIONE COORDINATE VALIDE PER LA DISTANZA

            float r = Float.parseFloat(raggio);
            for (int i = 0; i < coordinatenegozi.size(); i++) {
                Location l1 = new Location("loc1");

                l1.setLatitude(coordinatenegozi.get(i).getLatitude());
                l1.setLongitude(coordinatenegozi.get(i).getLongitude());
                float distance = mypos.distanceTo(l1) / 1000;


                if (distance <= r) {
                    valide.add(new LatLng(coordinatenegozi.get(i).getLatitude(), coordinatenegozi.get(i).getLongitude()));
                    nominegozi.add(res.get(i).get(1));
                    categorie.add(res.get(i).get(2));
                    uid.add(res.get(i).get(3));
                    feeds.add(res.get(i).get(4));
                    emails.add(res.get(i).get(5));
                }

            }

            mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(C));

            for (int i = 0; i < valide.size(); i++)
                mMap.addMarker(new MarkerOptions().
                        position(valide.get(i)).
                        title(nominegozi.get(i)).
                        snippet("Categoria: " + categorie.get(i) + "\nRating: " + feeds.get(i) + "/5" + "\nContact: " + emails.get(i)));

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(C, "error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
}
