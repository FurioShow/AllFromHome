package it.uniparthenope.AFH;

import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class VendorOrders_nav extends AppCompatActivity implements Popup_update_state.Updatestatelistener {


    private DatabaseReference db;
    private FirebaseAuth mAuth;
    private TableLayout table;
    private TableRow row, selected;
    private Button viewprod, update;
    private DrawerLayout drawer;
    private ArrayList<Order> orders;
    private ArrayList<String> uids;
    private int rowindex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_orders_nav);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Ordini ricevuti");
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if(isNetworkAvailable())
                try {
                    if (id == R.id.profile) {
                        Intent i = new Intent(VendorOrders_nav.this, VendorLogin.class);
                        startActivity(i);
                    } else if (id == R.id.products) {
                        Intent i = new Intent(VendorOrders_nav.this, VendorProducts_nav.class);
                        startActivity(i);
                    } else if (id == R.id.contactus) {
                        Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                    } else if (id == R.id.logout) {
                        mAuth.signOut();
                        Intent i = new Intent(VendorOrders_nav.this, MainActivity.class);
                        startActivity(i);

                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Service unavaible", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                else
                    Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                return false;
            }
        });


        mAuth = FirebaseAuth.getInstance();

        viewprod = findViewById(R.id.viewo);
        update = findViewById(R.id.update);
        viewprod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Popup_ViewOrders vieworder = new Popup_ViewOrders(orders.get((int) selected.getTag()),
                            getApplicationContext(), uids.get((int) selected.getTag()));
                    vieworder.show(getSupportFragmentManager(), "Order show");
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Errore visualizzazione ordine", Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Popup_update_state update = new Popup_update_state(getApplicationContext(), orders.get((int) selected.getTag()), uids.get((int) selected.getTag()));
                    update.show(getSupportFragmentManager(), "Aggiorna stato ordine");
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
        table = findViewById(R.id.table);
        db = FirebaseDatabase.getInstance().getReference().child("Orders");

        db.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uids = new ArrayList<>();
                orders = new ArrayList<>();
                rowindex = 0;
                try {
                    table.removeAllViews();
                    int i = 0;
                    for (DataSnapshot list : dataSnapshot.getChildren()) {
                        final Order order = list.getValue(Order.class);
                        if (order.getUidvendor().compareTo(mAuth.getUid()) == 0) {
                            row = new TableRow(VendorOrders_nav.this);
                            TextView textord = new TextView(VendorOrders_nav.this);
                            TextView uidprod = new TextView(VendorOrders_nav.this);
                            final String uid = list.getKey();
                            orders.add(order);
                            uids.add(uid);

                            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                                    TableRow.LayoutParams.WRAP_CONTENT);
                            float density = getApplicationContext().getResources().getDisplayMetrics().density; //Fattore per passare da dp a pixel
                            lp.setMargins((int) (20 * density), 0, 0, 0);


                            textord.setText("Ordine n° " + String.valueOf(i + 1) + " ID:");
                            uidprod.setText(uid);
                            i++;
                            textord.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                            uidprod.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                            row.addView(textord);
                            row.addView(uidprod,lp);


                            row.setClickable(true);
                            row.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (selected != null)
                                        selected.setBackgroundColor(Color.TRANSPARENT);
                                    selected = (TableRow) v;
                                    selected.setBackgroundColor(Color.RED);


                                }
                            });
                            row.setTag(rowindex);
                            rowindex++;
                            table.addView(row, new TableLayout.LayoutParams(
                                    TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));


                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void applytexts(String state, Order order, String uid) {
        DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Orders").child(uid);

        if (order.getState().toLowerCase().compareTo("in attesa di conferma") == 0 && state.toLowerCase().compareTo("consegnato") != 0) {
            data.child("state").setValue(state);
            Toast.makeText(getApplicationContext(), "State update success!", Toast.LENGTH_SHORT).show();
        } else if (order.getState().toLowerCase().compareTo("accettato") == 0 && state.toLowerCase().compareTo("consegnato") == 0) {
            data.child("state").setValue(state);
            Toast.makeText(getApplicationContext(), "State update success!", Toast.LENGTH_SHORT).show();
        } else
            Toast.makeText(getApplicationContext(), "update not valid", Toast.LENGTH_SHORT).show();
    }
}
