package it.uniparthenope.AFH;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import java.util.ArrayList;

public class Popup_update_state extends AppCompatDialogFragment {

    private Updatestatelistener listener;
    private Context context;
    private Spinner spinner;
    private Order order;
    private TextView currstate;
    private String uid;

    Popup_update_state(Context c, Order o, String u) {
        this.context = c;
        this.order = o;
        this.uid = u;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        try {
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.layout_update_state, null);
            spinner = view.findViewById(R.id.spinner);
            currstate = view.findViewById(R.id.currstate);
            currstate.setText("Stato corrente: " + order.getState());

            ArrayList<String> itemspinner = new ArrayList<>();
            itemspinner.add("Accettato");
            itemspinner.add("Rifiutato");
            itemspinner.add("Consegnato");
            ArrayAdapter<String> adapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, itemspinner);

            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);


            builder.setView(view)
                    .setTitle("Aggiorna stato ordine")
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            listener.applytexts(spinner.getSelectedItem().toString(), order, uid);

                        }
                    });

            return builder.create();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            listener = (Popup_update_state.Updatestatelistener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + "must implement updatelistener");
        }
    }

    public interface Updatestatelistener {
        void applytexts(String state, Order order, String uid);

    }
}
