package it.uniparthenope.AFH;

public class Feedback {
    private String uidvendor;
    private String uidbuyer;
    private int feed;

    public Feedback() {
    }

    public Feedback(String uidvendor, String uidbuyer, int feed) {
        this.uidvendor = uidvendor;
        this.uidbuyer = uidbuyer;
        this.feed = feed;

    }

    public String getUidvendor() {
        return uidvendor;
    }

    public void setUidvendor(String uidvendor) {
        this.uidvendor = uidvendor;
    }

    public String getUidbuyer() {
        return uidbuyer;
    }

    public void setUidbuyer(String uidbuyer) {
        this.uidbuyer = uidbuyer;
    }

    public int getFeed() {
        return feed;
    }

    public void setFeed(int feed) {
        this.feed = feed;
    }
}
