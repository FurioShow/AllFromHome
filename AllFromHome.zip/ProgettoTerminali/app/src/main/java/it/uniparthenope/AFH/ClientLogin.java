package it.uniparthenope.AFH;

import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;

import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ClientLogin extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Profilo");
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();
        retrieveinfo();
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                final LocationManager manager = (LocationManager) getSystemService(getApplicationContext().LOCATION_SERVICE);

                if (isNetworkAvailable())
                    try {
                        if (id == R.id.nav_orders) {
                            Intent i = new Intent(ClientLogin.this, ClientOrders_nav.class);
                            startActivity(i);
                        } else if (id == R.id.nav_map) {
                            if (!(manager.isProviderEnabled(LocationManager.GPS_PROVIDER)))
                                Toast.makeText(getApplicationContext(), "Abilita il tuo gps  e riprova", Toast.LENGTH_SHORT).show();
                            else {
                                Intent i = new Intent(ClientLogin.this, VendorMap_nav.class);
                                startActivity(i);
                            }
                        } else if (id == R.id.contactus) {
                            Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                        } else if (id == R.id.logout) {
                            mAuth.signOut();
                            Intent i = new Intent(ClientLogin.this, MainActivity.class);
                            startActivity(i);

                        }
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Service unavaible", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                else
                    Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                return false;
            }
        });
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager connectivityManager
                    = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void retrieveinfo() {
        try {
            final TextView nomecogn, indirizzo, phone, email;
            nomecogn = findViewById(R.id.name);
            indirizzo = findViewById(R.id.address);
            phone = findViewById(R.id.mobileNumber);
            email = findViewById(R.id.email);

            DatabaseReference db = FirebaseDatabase.getInstance().getReference().child("Users").child(mAuth.getUid());
            db.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User u = dataSnapshot.getValue(User.class);

                    nomecogn.setText(u.getNome() + " " + u.getCognome());
                    indirizzo.setText(u.getIndirizzo().toUpperCase());
                    phone.setText(u.getNumber());
                    email.setText(u.getEmail());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            System.exit(0);
        }
    }
}
