package it.uniparthenope.AFH;

import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


public class VendorProducts_nav extends AppCompatActivity implements Popup_AddProduct.AddProductListener {
    private Button add, modify;
    private TableLayout table;
    private TextView nome;
    private TableRow row, selected;
    private TextView categ, desc, prezzo, quantita, unita;
    private FirebaseAuth mAuth;
    private DatabaseReference db;
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_vendor_products_nav);
            Toolbar toolbar = findViewById(R.id.toolbar);
            toolbar.setTitle("Gestisci i tuoi prodotti");
            setSupportActionBar(toolbar);

            drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                    R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();

            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int id = item.getItemId();

                    if (isNetworkAvailable())
                        try {
                            if (id == R.id.profile) {
                                Intent i = new Intent(VendorProducts_nav.this, VendorLogin.class);
                                startActivity(i);
                            } else if (id == R.id.orders) {
                                Intent i = new Intent(VendorProducts_nav.this, VendorOrders_nav.class);
                                startActivity(i);
                            } else if (id == R.id.contactus) {
                                Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                            } else if (id == R.id.logout) {
                                mAuth.signOut();
                                Intent i = new Intent(VendorProducts_nav.this, MainActivity.class);
                                startActivity(i);

                            }
                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Service unavaible", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    else
                        Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                    return false;
                }
            });

            mAuth = FirebaseAuth.getInstance();
            add = findViewById(R.id.add);
            table = findViewById(R.id.table);


            modify = findViewById(R.id.modify);
            riempiTable();


            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openDialog(0);
                }
            });

            modify.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openDialog(1);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void openDialog(int i) {
        try {
            Popup_AddProduct popup = null;
            if (i == 0)    //Se aggiungi
                popup = new Popup_AddProduct(-1);
            else if (i == 1)   //Se modifichi/elmini
            {
                if (selected != null) {
                    TextView c = (TextView) selected.getChildAt(0);
                    TextView d = (TextView) selected.getChildAt(1);
                    popup = new Popup_AddProduct(c.getText().toString(), d.getText().toString());
                } else {
                    Toast.makeText(this, "Seleziona un prodotto", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            popup.show(getSupportFragmentManager(), "Popup_AddProduct");
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void riempiTable() {
        try {
            db = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("Products");
            db.addValueEventListener(new ValueEventListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
                    float density = getApplicationContext().getResources().getDisplayMetrics().density; //Fattore per passare da dp a pixel
                    lp.setMargins((int) (20 * density), 0, 0, 0);

                    TableRow first = (TableRow) table.getChildAt(0);
                    table.removeAllViews();
                    table.addView(first, lp);

                    for (DataSnapshot list : dataSnapshot.getChildren()) {
                        row = new TableRow(VendorProducts_nav.this);

                        row.setClickable(true);
                        desc = new TextView(VendorProducts_nav.this);
                        prezzo = new TextView(VendorProducts_nav.this);
                        quantita = new TextView(VendorProducts_nav.this);
                        categ = new TextView(VendorProducts_nav.this);
                        Product prod = list.getValue(Product.class);
                        categ.setText(prod.getCateg());
                        categ.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                        desc.setText(prod.getDesc());
                        desc.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                        quantita.setText(Double.toString(prod.getQuantita()) + prod.getUnita());
                        quantita.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                        prezzo.setText(Double.toString(prod.getPrezzo()) + " al " + prod.getUnita());
                        prezzo.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                        row.addView(categ);
                        row.addView(desc, lp);
                        row.addView(quantita, lp);
                        row.addView(prezzo, lp);

                        row.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (selected != null)
                                    selected.setBackgroundColor(Color.TRANSPARENT);
                                selected = (TableRow) v;
                                selected.setBackgroundColor(Color.RED);
                            }
                        });
                        table.addView(row, lp);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(VendorProducts_nav.this, "Error!", Toast.LENGTH_SHORT);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override   //DA OTTIMIZZARE
    public void add(String categoria, String descrizione, double quantita, double prezzo, String unita) {
        db = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("Products").push();
        Product prod = new Product(categoria, descrizione, prezzo, quantita, unita);
        db.setValue(prod);
    }


    @Override //DA OTTIMIZZARE
    public void delete() {
        db = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("Products");
        final int k = table.indexOfChild(selected);
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i = 1;
                for (DataSnapshot list : dataSnapshot.getChildren()) {
                    if (i == k) {
                        list.getRef().setValue(null);
                        table.removeView(selected);
                    }
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    @Override //DA OTTIMIZZARE
    public void update(final String categoria, final String descrizione, final double quantita, final double prezzo, final String unita) {
        db = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("Products");
        final int k = table.indexOfChild(selected);
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i = 1;
                for (DataSnapshot list : dataSnapshot.getChildren()) {
                    if (i == k) {
                        Product prod = new Product(categoria, descrizione, prezzo, quantita, unita);
                        list.getRef().setValue(prod);
                    }
                    i++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
