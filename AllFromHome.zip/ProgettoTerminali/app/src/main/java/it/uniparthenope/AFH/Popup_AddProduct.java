package it.uniparthenope.AFH;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import java.util.ArrayList;
import java.util.Arrays;

public class Popup_AddProduct extends AppCompatDialogFragment {
    private Spinner categ, unita;
    private EditText desc, quant, prezz;
    private String cat, descriz;
    private int mod;        //Se -1 si è cliccato su Add, altrimenti su Modify
    private AddProductListener listener;

    public Popup_AddProduct(int mod) {
        this.mod = mod;
    }

    public Popup_AddProduct(String cat, String descriz) {
        this.cat = cat;
        this.descriz = descriz;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (Popup_AddProduct.AddProductListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " deve essere implementata AddProductListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.popup_add_product, null);
            categ = view.findViewById(R.id.categoria);
            unita = view.findViewById(R.id.unita);
            desc = view.findViewById(R.id.desc);
            quant = view.findViewById(R.id.stato);
            prezz = view.findViewById(R.id.prezzo);
            ArrayList<String> list = new ArrayList<>(Arrays.asList("Pane", "Dolci", "Verdura", "Frutta"));
            ArrayAdapter<String> adap = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, list);
            categ.setAdapter(adap);
            ArrayList<String> list1 = new ArrayList<>(Arrays.asList("Kg", "Lt", "Pzz"));
            ArrayAdapter<String> adap1 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, list1);
            unita.setAdapter(adap1);


            if (mod == -1) {
                builder.setView(view)
                        .setTitle("Aggiungi prodotto")
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (categ.getSelectedItem().toString().isEmpty() || desc.getText().toString().isEmpty() || quant.getText().toString().isEmpty() ||
                                        prezz.getText().toString().isEmpty() || unita.getSelectedItem().toString().isEmpty())
                                    Toast.makeText(getContext(), "Inserimento fallito, riempi il form", Toast.LENGTH_SHORT).show();
                                else
                                    listener.add(categ.getSelectedItem().toString(), desc.getText().toString(), Double.parseDouble(quant.getText().toString()),
                                            Double.parseDouble(prezz.getText().toString()), unita.getSelectedItem().toString());
                            }
                        });
                return builder.create();
            } else {
                desc.setText(descriz);
                builder.setView(view)
                        .setTitle("Modifica Prodotto")
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .setNeutralButton("Elimina", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                listener.delete();
                            }
                        })
                        .setPositiveButton("Modifica", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (categ.getSelectedItem().toString().isEmpty() || desc.getText().toString().isEmpty() || quant.getText().toString().isEmpty() ||
                                        prezz.getText().toString().isEmpty() || unita.getSelectedItem().toString().isEmpty())
                                    Toast.makeText(getContext(), "Modifica fallita, riempi il form", Toast.LENGTH_SHORT).show();
                                else
                                    listener.update(categ.getSelectedItem().toString(), desc.getText().toString(),
                                            Double.parseDouble(quant.getText().toString()), Double.parseDouble(prezz.getText().toString()), unita.getSelectedItem().toString());
                            }
                        });
                return builder.create();
            }
        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }

    public interface AddProductListener {
        void add(String categoria, String descrizione, double quantita, double prezzo, String unita);

        void delete();

        void update(String categoria, String descrizione, double quantita, double prezzo, String unita);
    }
}
