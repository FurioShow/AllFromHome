package it.uniparthenope.AFH;

public class Product {
    String categ;
    String desc;
    double prezzo;
    double quantita;
    String unita;

    public String getCateg() {
        return categ;
    }

    public void setCateg(String categ) {
        this.categ = categ;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(double prezzo) {
        this.prezzo = prezzo;
    }

    public double getQuantita() {
        return quantita;
    }

    public void setQuantita(double quantita) {
        this.quantita = quantita;
    }

    public String getUnita() {
        return unita;
    }

    public void setUnita(String unita) {
        this.unita = unita;
    }

    public Product(){}

    public Product(String categ, String desc, double prezzo, double quantita, String unita) {
        this.categ = categ;
        this.desc = desc;
        this.prezzo = prezzo;
        this.quantita = quantita;
        this.unita = unita;
    }

    public Product(String categ, String desc, double prezzo, double quantita) {
        this.categ = categ;
        this.desc = desc;
        this.prezzo = prezzo;
        this.quantita = quantita;
    }
}
