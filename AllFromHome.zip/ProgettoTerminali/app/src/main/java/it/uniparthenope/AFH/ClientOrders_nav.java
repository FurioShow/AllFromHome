package it.uniparthenope.AFH;

import android.content.Intent;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import java.util.ArrayList;

public class ClientOrders_nav extends AppCompatActivity {

    private TableLayout table;
    private TableRow row, selected;
    private Button viewprod;
    private Button cancelorder;
    private DatabaseReference db;
    private FirebaseAuth mAuth;
    private DrawerLayout drawer;
    private ArrayList<Order> orders;
    private ArrayList<String> uids;
    private int rowindex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_orders_nav);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("I tuoi ordini");
        setSupportActionBar(toolbar);


        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                final LocationManager manager = (LocationManager) getSystemService(getApplicationContext().LOCATION_SERVICE);

                if (isNetworkAvailable())
                    try {
                        if (id == R.id.profile) {
                            Intent i = new Intent(ClientOrders_nav.this, ClientLogin.class);
                            startActivity(i);
                        } else if (id == R.id.map) {
                            if (!(manager.isProviderEnabled(LocationManager.GPS_PROVIDER)))
                                Toast.makeText(getApplicationContext(), "Abilita il tuo gps per mostrare la mappa", Toast.LENGTH_SHORT).show();
                            else {
                                Intent i = new Intent(ClientOrders_nav.this, VendorMap_nav.class);
                                startActivity(i);
                            }
                        } else if (id == R.id.contactus) {
                            Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                        } else if (id == R.id.logout) {
                            mAuth.signOut();
                            Intent i = new Intent(ClientOrders_nav.this, MainActivity.class);
                            startActivity(i);

                        }
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Service unavaible", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                else
                    Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                return false;
            }
        });


        mAuth = FirebaseAuth.getInstance();

        table = findViewById(R.id.table);
        db = FirebaseDatabase.getInstance().getReference().child("Orders");
        cancelorder = findViewById(R.id.canc);
        viewprod = findViewById(R.id.viewp);
        viewprod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                try {
                    Popup_ViewOrders viewOrders = new Popup_ViewOrders(orders.get((int) selected.getTag()), getApplicationContext(), uids.get((int) selected.getTag()));
                    viewOrders.show(getSupportFragmentManager(), "View order");
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Errore visualizzazione ordine", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });

        cancelorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (orders.get((int) selected.getTag()).getState().toLowerCase().compareTo("accettato") == 0)
                        Toast.makeText(getApplicationContext(), "Non è possibile cancellare l'ordine a causa del suo stato",
                                Toast.LENGTH_SHORT).show();
                    else {
                        DatabaseReference data = FirebaseDatabase.getInstance().getReference().child("Orders")
                                .child(uids.get((int) selected.getTag()));
                        data.removeValue();
                        Toast.makeText(getApplicationContext(), "Order cancelled!",
                                Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        db.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uids = new ArrayList<>();
                orders = new ArrayList<>();
                rowindex = 0;
                try {
                    table.removeAllViews();
                    int i = 0;
                    for (DataSnapshot list : dataSnapshot.getChildren()) {
                        final Order order = list.getValue(Order.class);
                        if (order.getUidbuyer().compareTo(mAuth.getUid()) == 0) {
                            row = new TableRow(ClientOrders_nav.this);
                            TextView textord = new TextView(ClientOrders_nav.this);
                            TextView uidprod = new TextView(ClientOrders_nav.this);
                            final String uid = list.getKey();
                            orders.add(order);
                            uids.add(uid);

                            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                                    TableRow.LayoutParams.WRAP_CONTENT);
                            float density = getApplicationContext().getResources().getDisplayMetrics().density; //Fattore per passare da dp a pixel
                            lp.setMargins((int) (20 * density), 0, 0, 0);


                            textord.setText("Ordine n° " + String.valueOf(i + 1) + " ID:");
                            uidprod.setText(uid);
                            i++;
                            textord.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);
                            uidprod.setTextAppearance(R.style.TextAppearance_AppCompat_Body1);

                            row.addView(textord,new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                                    TableRow.LayoutParams.WRAP_CONTENT));
                            row.addView(uidprod, lp);


                            row.setClickable(true);
                            row.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (selected != null)
                                        selected.setBackgroundColor(Color.TRANSPARENT);
                                    selected = (TableRow) v;
                                    selected.setBackgroundColor(Color.RED);


                                }
                            });
                            row.setTag(rowindex);
                            rowindex++;
                            table.addView(row, new TableLayout.LayoutParams(
                                    TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));


                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

}
