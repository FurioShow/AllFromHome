package it.uniparthenope.AFH;

import android.content.Intent;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.FragmentActivity;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VendorMap_nav extends FragmentActivity implements OnMapReadyCallback {


    private com.google.android.gms.maps.GoogleMap mMap;
    private Button visit;
    private String titolonegozio, emailvendor;
    private Location mypos;

    private String uidvendor;
    private DrawerLayout drawer;
    private Spinner raggiosp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_map_nav);
        raggiosp = findViewById(R.id.raggiosp);


        ArrayList<String> itemspinner = new ArrayList<>();
        itemspinner.add("5");
        itemspinner.add("10");
        itemspinner.add("25");
        itemspinner.add("50");
        itemspinner.add("100");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, itemspinner);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        raggiosp.setAdapter(adapter);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Mappa venditori");
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (isNetworkAvailable())
                    try {
                        if (id == R.id.profile) {
                            Intent i = new Intent(VendorMap_nav.this, ClientLogin.class);
                            startActivity(i);
                        } else if (id == R.id.orders) {
                            Intent i = new Intent(VendorMap_nav.this, ClientOrders_nav.class);
                            startActivity(i);
                        } else if (id == R.id.contactus) {
                            Toast.makeText(getApplicationContext(), "Contacts us:" + " " + getString(R.string.contact_on), Toast.LENGTH_SHORT).show();
                        } else if (id == R.id.logout) {
                            FirebaseAuth.getInstance().signOut();
                            Intent i = new Intent(VendorMap_nav.this, MainActivity.class);
                            startActivity(i);

                        }
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Service unavaible", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                else
                    Toast.makeText(getApplicationContext(), "Verifica la tua connessione internet e riprova", Toast.LENGTH_SHORT).show();

                return false;
            }
        });


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null)
            mapFragment.getMapAsync(this);


        visit = findViewById(R.id.button2);


        visit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(VendorMap_nav.this, OpenVendor.class);
                i.putExtra("uid", uidvendor);
                i.putExtra("negozio", titolonegozio);
                startActivity(i);

            }
        });
    }

    @Override
    public void onMapReady(com.google.android.gms.maps.GoogleMap googleMap) {
        mMap = googleMap;
        mypos = new Gpstracker(getApplicationContext()).getlocation();


        try {
            mMap.setMyLocationEnabled(true);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(mypos.getLatitude(), mypos.getLongitude())));

            //Per lo zoom
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mypos.getLatitude(), mypos.getLongitude()), 15.0f));

            //VENGONO SETTATI I PRIMI MARKER CON RAGGIO DI 5KM
            mMap.clear();
            Init_mappa init = new Init_mappa();
            init.initialize(getApplicationContext(), raggiosp.getSelectedItem().toString(), mMap);

            raggiosp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    mMap.clear();
                    Init_mappa init = new Init_mappa();
                    init.initialize(getApplicationContext(), raggiosp.getSelectedItem().toString(), mMap);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    mMap.clear();
                }
            });


            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(final Marker marker) {

                    titolonegozio = marker.getTitle();
                    visit.setVisibility(View.VISIBLE);
                    uidvendor = "";
                    emailvendor = "";
                    try {
                        DatabaseReference getuid = FirebaseDatabase.getInstance().getReference().child("Users");
                        if (marker.getSnippet() != null) {
                            Matcher m = Pattern.compile("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+").matcher(marker.getSnippet());
                            if (m.find()) {
                                emailvendor = m.group();

                                getuid.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                        try {
                                            for (DataSnapshot list : dataSnapshot.getChildren()) {
                                                if (list.getValue(User.class).getEmail().compareTo(emailvendor) == 0)
                                                    uidvendor = list.getKey();
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }
            });

            mMap.setOnInfoWindowCloseListener(new GoogleMap.OnInfoWindowCloseListener() {
                @Override
                public void onInfoWindowClose(Marker marker) {
                    visit.setVisibility(View.INVISIBLE);
                }
            });

            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(VendorMap_nav.this, OpenVendor.class);
                    i.putExtra("uid", uidvendor);
                    i.putExtra("negozio", titolonegozio);
                    startActivity(i);
                }
            });


        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager connectivityManager
                    = (ConnectivityManager) getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Si è verificato un errore: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
